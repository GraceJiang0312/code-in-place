from ai import call_gpt
import os

def main():
    # TODO: your code here
    name = input("Please enter your name: ")
    topic = input("Enter a topic for your haiku: ")

    prompt = (
        f"Write a haiku for a person named {name}, about the topic '{topic}'. "
        "The haiku should follow the 5-7-5 syllable format and evoke a calm or thoughtful mood. "
        "Use imagery from nature if possible."
    )

    haiku = call_gpt(prompt)
    print(f"Creating your haiku...")
    print(haiku)

if __name__ == "__main__":
    main()